nome = input('Digite seu nome ')

print('Bom dia {}' .format(nome))