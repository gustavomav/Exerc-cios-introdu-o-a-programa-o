num1 = 2

soma = num1 + 6
divi = 16 / num1
multi = num1 * 4
sub = 10 - num1

print(soma)
print(divi)
print(multi)
print(sub)