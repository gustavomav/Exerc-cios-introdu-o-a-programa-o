nome = input('Digite seu nome ')

print('Bem vinda a festa Sr(a). {}' .format(nome.upper()))






