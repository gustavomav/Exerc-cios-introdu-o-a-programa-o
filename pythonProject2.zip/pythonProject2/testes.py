num1 = int(input('Digite um numero '))

num2 = int(input('Digite outro numero'))

soma = num1 + num2

print(soma)