num1 = int(input('Digite o primeiro numero: '))

soma = num1 + 1357
mult = soma * 8

resultado = mult/5**2


print(resultado)

